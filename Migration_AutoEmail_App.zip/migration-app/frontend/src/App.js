// App.js — Migration Auto-Email Tool Frontend

import { useState, useRef } from "react";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || "http://localhost:3001";

const STATUS = { IDLE: "idle", PREVIEWING: "previewing", PROCESSING: "processing", DONE: "done", ERROR: "error" };

export default function App() {
  const [file, setFile]         = useState(null);
  const [status, setStatus]     = useState(STATUS.IDLE);
  const [preview, setPreview]   = useState(null);
  const [results, setResults]   = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef();

  // ── File handling ────────────────────────────────────────────────────────────
  function handleFile(f) {
    if (!f) return;
    if (!f.name.endsWith(".zip")) {
      setErrorMsg("Please upload a .zip file from Migration Manager.");
      return;
    }
    setFile(f);
    setStatus(STATUS.IDLE);
    setPreview(null);
    setResults(null);
    setErrorMsg("");
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files[0]);
  }

  // ── Preview (parse without sending) ─────────────────────────────────────────
  async function handlePreview() {
    if (!file) return;
    setStatus(STATUS.PREVIEWING);
    setErrorMsg("");
    try {
      const fd = new FormData();
      fd.append("migrationZip", file);
      const res  = await fetch(`${BACKEND_URL}/api/preview-migration`, { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || "Preview failed");
      setPreview(data);
      setStatus(STATUS.IDLE);
    } catch (err) {
      setErrorMsg(err.message);
      setStatus(STATUS.ERROR);
    }
  }

  // ── Process (parse + send emails) ───────────────────────────────────────────
  async function handleProcess() {
    if (!file) return;
    setStatus(STATUS.PROCESSING);
    setErrorMsg("");
    try {
      const fd = new FormData();
      fd.append("migrationZip", file);
      const res  = await fetch(`${BACKEND_URL}/api/process-migration`, { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || "Processing failed");
      setResults(data);
      setStatus(STATUS.DONE);
    } catch (err) {
      setErrorMsg(err.message);
      setStatus(STATUS.ERROR);
    }
  }

  function reset() {
    setFile(null); setStatus(STATUS.IDLE);
    setPreview(null); setResults(null); setErrorMsg("");
  }

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <div style={s.page}>
      <div style={s.card}>

        {/* Header */}
        <div style={s.header}>
          <div>
            <h1 style={s.h1}>Migration Auto-Email Tool</h1>
            <p style={s.subtitle}>CHSPSC LLC — IT Migration Team</p>
          </div>
          <div style={s.badge}>Powered by Power Automate</div>
        </div>

        {/* Step indicators */}
        <div style={s.steps}>
          {["Upload ZIP", "Preview", "Send Emails"].map((label, i) => {
            const active = (i === 0 && status === STATUS.IDLE && !preview) ||
                           (i === 1 && preview && status !== STATUS.DONE) ||
                           (i === 2 && status === STATUS.DONE);
            return (
              <div key={i} style={s.stepItem}>
                <div style={{ ...s.stepCircle, background: active ? "#0078D4" : "#e5e7eb", color: active ? "#fff" : "#6b7280" }}>{i + 1}</div>
                <span style={{ ...s.stepLabel, color: active ? "#0078D4" : "#6b7280", fontWeight: active ? 500 : 400 }}>{label}</span>
                {i < 2 && <div style={s.stepLine}/>}
              </div>
            );
          })}
        </div>

        {/* Drop zone */}
        {!results && (
          <div
            style={{ ...s.dropzone, ...(dragOver ? s.dropzoneActive : {}), ...(file ? s.dropzoneFilled : {}) }}
            onClick={() => inputRef.current.click()}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
          >
            <input ref={inputRef} type="file" accept=".zip" style={{ display: "none" }} onChange={e => handleFile(e.target.files[0])}/>
            {file ? (
              <div style={s.fileInfo}>
                <span style={s.fileIcon}>📦</span>
                <div>
                  <p style={s.fileName}>{file.name}</p>
                  <p style={s.fileSize}>{(file.size / 1024).toFixed(1)} KB — ready to process</p>
                </div>
                <button style={s.removeBtn} onClick={e => { e.stopPropagation(); reset(); }}>✕</button>
              </div>
            ) : (
              <div style={{ textAlign: "center" }}>
                <p style={s.dropIcon}>📂</p>
                <p style={s.dropTitle}>Drop your migration ZIP here</p>
                <p style={s.dropSub}>or click to browse — accepts Migration_summary_report ZIP from Microsoft 365</p>
              </div>
            )}
          </div>
        )}

        {/* Error */}
        {errorMsg && (
          <div style={s.errorBox}>
            <strong>Error:</strong> {errorMsg}
          </div>
        )}

        {/* Action buttons */}
        {file && !results && (
          <div style={s.btnRow}>
            <button
              style={{ ...s.btn, ...s.btnSecondary }}
              onClick={handlePreview}
              disabled={status === STATUS.PREVIEWING || status === STATUS.PROCESSING}
            >
              {status === STATUS.PREVIEWING ? "⏳ Parsing..." : "🔍 Preview errors"}
            </button>
            <button
              style={{ ...s.btn, ...s.btnPrimary, ...(!preview ? s.btnDisabled : {}) }}
              onClick={handleProcess}
              disabled={!preview || status === STATUS.PROCESSING}
            >
              {status === STATUS.PROCESSING ? "⏳ Sending emails..." : "✉ Send all emails"}
            </button>
          </div>
        )}

        {/* Preview panel */}
        {preview && !results && (
          <div style={s.panel}>
            <div style={s.panelHeader}>
              <h2 style={s.h2}>Preview — {preview.affectedUsers} user(s) found</h2>
              <div style={s.statRow}>
                <Stat label="Users affected" value={preview.affectedUsers} color="#0078D4"/>
                <Stat label="Total errors" value={preview.totalErrors} color="#C00000"/>
                <Stat label="Source file" value={preview.sourceFile} color="#6B7280" small/>
              </div>
            </div>
            <div style={s.tableWrap}>
              <table style={s.table}>
                <thead>
                  <tr>
                    {["User email","Errors","Error codes","Files (sample)"].map(h => (
                      <th key={h} style={s.th}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {preview.users.map((u, i) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                      <td style={s.td}>{u.userEmail}</td>
                      <td style={{ ...s.td, color: "#C00000", fontWeight: 500 }}>{u.errorCount}</td>
                      <td style={s.td}>
                        {u.errorCodes.map(c => (
                          <span key={c} style={s.codePill}>{c}</span>
                        ))}
                      </td>
                      <td style={{ ...s.td, color: "#6b7280", fontSize: 12 }}>
                        {u.preview.map(p => p.file).join(", ")}
                        {u.errorCount > 3 ? ` +${u.errorCount - 3} more` : ""}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p style={s.previewNote}>
              ✉ Each user will receive a professional email with the errors listed above + a CSV attachment with full details and solutions.
            </p>
          </div>
        )}

        {/* Results panel */}
        {results && (
          <div style={s.panel}>
            <div style={{ ...s.panelHeader, background: "#F0FDF4", borderColor: "#BBF7D0" }}>
              <h2 style={{ ...s.h2, color: "#166534" }}>✅ Complete — {results.successCount} email(s) sent</h2>
              <div style={s.statRow}>
                <Stat label="Emails sent"   value={results.successCount} color="#16A34A"/>
                <Stat label="Failed"        value={results.failedCount}  color={results.failedCount > 0 ? "#C00000" : "#6B7280"}/>
                <Stat label="Users notified" value={results.affectedUsers} color="#0078D4"/>
              </div>
            </div>
            <div style={s.tableWrap}>
              <table style={s.table}>
                <thead>
                  <tr>
                    {["User email","Errors","CSV report","Status"].map(h => (
                      <th key={h} style={s.th}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {results.results.map((r, i) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                      <td style={s.td}>{r.userEmail}</td>
                      <td style={{ ...s.td, color: "#C00000", fontWeight: 500 }}>{r.errorCount}</td>
                      <td style={{ ...s.td, fontSize: 12, color: "#6b7280" }}>{r.csvFileName}</td>
                      <td style={s.td}>
                        <span style={{ ...s.statusPill, background: r.status === "triggered" ? "#DCFCE7" : "#FEE2E2", color: r.status === "triggered" ? "#166534" : "#991B1B" }}>
                          {r.status === "triggered" ? "✓ Sent" : "✗ Failed"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={s.btnRow}>
              <button style={{ ...s.btn, ...s.btnSecondary }} onClick={reset}>Process another ZIP</button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

function Stat({ label, value, color, small }) {
  return (
    <div style={{ textAlign: "center", minWidth: 80 }}>
      <p style={{ margin: 0, fontSize: small ? 13 : 22, fontWeight: 500, color }}>{value}</p>
      <p style={{ margin: "2px 0 0", fontSize: 12, color: "#6b7280" }}>{label}</p>
    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = {
  page:         { minHeight: "100vh", background: "#f3f4f6", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "32px 16px", fontFamily: "Segoe UI, Arial, sans-serif" },
  card:         { background: "#fff", borderRadius: 12, border: "1px solid #e5e7eb", width: "100%", maxWidth: 780, overflow: "hidden" },
  header:       { background: "#0078D4", padding: "24px 32px", display: "flex", justifyContent: "space-between", alignItems: "center" },
  h1:           { margin: 0, fontSize: 20, fontWeight: 600, color: "#fff" },
  subtitle:     { margin: "4px 0 0", fontSize: 13, color: "#cce4f7" },
  badge:        { background: "rgba(255,255,255,0.2)", color: "#fff", fontSize: 12, padding: "4px 12px", borderRadius: 20 },
  steps:        { display: "flex", alignItems: "center", padding: "20px 32px", borderBottom: "1px solid #f0f0f0" },
  stepItem:     { display: "flex", alignItems: "center", flex: 1 },
  stepCircle:   { width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 600, flexShrink: 0 },
  stepLabel:    { fontSize: 13, marginLeft: 8 },
  stepLine:     { flex: 1, height: 1, background: "#e5e7eb", margin: "0 12px" },
  dropzone:     { margin: "24px 32px", border: "1.5px dashed #d1d5db", borderRadius: 10, padding: "36px 24px", cursor: "pointer", transition: "all 0.2s", textAlign: "center" },
  dropzoneActive: { borderColor: "#0078D4", background: "#EFF6FF" },
  dropzoneFilled: { borderColor: "#0078D4", background: "#F0F9FF", borderStyle: "solid" },
  dropIcon:     { fontSize: 36, margin: "0 0 12px" },
  dropTitle:    { margin: "0 0 6px", fontSize: 15, fontWeight: 500, color: "#111" },
  dropSub:      { margin: 0, fontSize: 13, color: "#6b7280" },
  fileInfo:     { display: "flex", alignItems: "center", gap: 14, textAlign: "left" },
  fileIcon:     { fontSize: 32 },
  fileName:     { margin: 0, fontSize: 14, fontWeight: 500, color: "#111" },
  fileSize:     { margin: "2px 0 0", fontSize: 12, color: "#6b7280" },
  removeBtn:    { marginLeft: "auto", background: "none", border: "none", fontSize: 16, color: "#6b7280", cursor: "pointer", padding: "4px 8px" },
  btnRow:       { display: "flex", gap: 12, padding: "0 32px 24px" },
  btn:          { flex: 1, padding: "11px 20px", borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: "pointer", border: "none", transition: "opacity 0.15s" },
  btnPrimary:   { background: "#0078D4", color: "#fff" },
  btnSecondary: { background: "#f3f4f6", color: "#374151", border: "1px solid #e5e7eb" },
  btnDisabled:  { opacity: 0.5, cursor: "not-allowed" },
  errorBox:     { margin: "0 32px 16px", padding: "12px 16px", background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 8, fontSize: 13, color: "#991B1B" },
  panel:        { margin: "0 0 0", border: "none" },
  panelHeader:  { background: "#F8FAFC", borderTop: "1px solid #e5e7eb", borderBottom: "1px solid #e5e7eb", padding: "16px 32px" },
  h2:           { margin: "0 0 12px", fontSize: 16, fontWeight: 600, color: "#111" },
  statRow:      { display: "flex", gap: 24 },
  tableWrap:    { overflowX: "auto", padding: "0 32px" },
  table:        { width: "100%", borderCollapse: "collapse", fontSize: 13, marginTop: 16 },
  th:           { padding: "10px 12px", textAlign: "left", background: "#F1F5F9", fontWeight: 600, color: "#374151", borderBottom: "1px solid #e5e7eb", whiteSpace: "nowrap" },
  td:           { padding: "10px 12px", color: "#374151", borderBottom: "1px solid #f0f0f0", verticalAlign: "top" },
  codePill:     { display: "inline-block", background: "#FEF3C7", color: "#92400E", fontSize: 11, padding: "2px 6px", borderRadius: 4, marginRight: 4, marginBottom: 2 },
  statusPill:   { display: "inline-block", fontSize: 12, padding: "3px 10px", borderRadius: 20, fontWeight: 500 },
  previewNote:  { padding: "12px 32px 20px", margin: 0, fontSize: 13, color: "#4B5563", background: "#F8FAFC", borderTop: "1px solid #e5e7eb" },
};
