// index.js — Migration Auto-Email Backend Server

require("dotenv").config();
const express  = require("express");
const cors     = require("cors");
const multer   = require("multer");
const axios    = require("axios");
const { parseZip }       = require("./zipParser");
const { buildUserCSV }   = require("./csvBuilder");
const { buildEmailBody } = require("./emailBuilder");

const app    = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// ── CORS ──────────────────────────────────────────────────────────────────────
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || "*",
    "http://localhost:3000",
    "http://localhost:5173",
  ],
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

app.use(express.json());

// ── Health check ──────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Main endpoint: Upload ZIP → parse → trigger Power Automate ────────────────
app.post("/api/process-migration", upload.single("migrationZip"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: "No ZIP file uploaded" });
    }
    if (!req.file.originalname.endsWith(".zip")) {
      return res.status(400).json({ success: false, error: "File must be a .zip" });
    }

    const powerAutomateUrl = process.env.POWER_AUTOMATE_URL;
    if (!powerAutomateUrl || powerAutomateUrl.includes("YOUR_FLOW_URL_HERE")) {
      return res.status(500).json({ success: false, error: "Power Automate URL not configured in .env" });
    }

    console.log(`Processing: ${req.file.originalname} (${(req.file.size / 1024).toFixed(1)} KB)`);

    // 1. Parse ZIP
    const { userMap, summaryMap, sourceFile, affectedUsers } = parseZip(
      req.file.buffer,
      req.file.originalname
    );

    if (affectedUsers === 0) {
      return res.status(400).json({ success: false, error: "No user errors found in the ZIP file" });
    }

    // 2. Process each user — build CSV + trigger Power Automate
    const results = [];

    for (const [userEmail, errors] of Object.entries(userMap)) {
      const summary = summaryMap[userEmail] || { sourceFile };
      summary.sourceFile = sourceFile;

      console.log(`  → Processing ${userEmail} (${errors.length} errors)`);

      // Build CSV attachment
      const csvContent = buildUserCSV(userEmail, errors, summary);
      const csvBase64  = Buffer.from(csvContent, "utf8").toString("base64");
      const csvName    = `${userEmail.split("@")[0]}_migration_errors.csv`;

      // Build HTML email body
      const emailHtml  = buildEmailBody(userEmail, errors, summary);
      const errorCount = errors.length;
      const subject    = `[Migration Update] ${errorCount} item(s) from your Google Drive migration need attention`;

      // Trigger Power Automate HTTP endpoint
      try {
        const payload = {
          userEmail,
          subject,
          emailBody:       emailHtml,
          csvAttachment:   csvBase64,
          csvFileName:     csvName,
          errorCount,
          sourceFile,
          itAdminEmail:    process.env.IT_ADMIN_EMAIL || "it-admin@chs.net",
          timestamp:       new Date().toISOString(),
        };

        const paResponse = await axios.post(powerAutomateUrl, payload, {
          headers: { "Content-Type": "application/json" },
          timeout: 30000,
        });

        results.push({
          userEmail,
          errorCount,
          csvFileName: csvName,
          status: "triggered",
          paStatus: paResponse.status,
        });

        console.log(`  ✓ Triggered for ${userEmail} — PA status: ${paResponse.status}`);

      } catch (paError) {
        console.error(`  ✗ Power Automate failed for ${userEmail}:`, paError.message);
        results.push({
          userEmail,
          errorCount,
          csvFileName: csvName,
          status: "failed",
          error: paError.message,
        });
      }

      // Small delay between users to avoid rate limiting
      await new Promise(r => setTimeout(r, 300));
    }

    const successCount = results.filter(r => r.status === "triggered").length;
    const failedCount  = results.filter(r => r.status === "failed").length;

    return res.json({
      success: true,
      message: `Processed ${affectedUsers} user(s). ${successCount} email(s) triggered, ${failedCount} failed.`,
      sourceFile,
      affectedUsers,
      successCount,
      failedCount,
      results,
    });

  } catch (err) {
    console.error("Processing error:", err);
    return res.status(500).json({
      success: false,
      error: err.message || "Internal server error",
    });
  }
});

// ── Preview endpoint: returns parsed data without sending (for testing) ────────
app.post("/api/preview-migration", upload.single("migrationZip"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const { userMap, summaryMap, sourceFile, affectedUsers, totalErrors } = parseZip(
      req.file.buffer,
      req.file.originalname
    );

    const preview = Object.entries(userMap).map(([email, errors]) => ({
      userEmail: email,
      errorCount: errors.length,
      errorCodes: [...new Set(errors.map(e => e.ResultCode))],
      preview: errors.slice(0, 3).map(e => ({
        file: e.FullPath ? e.FullPath.split("/").pop() : "Unknown",
        code: e.ResultCode,
        reason: e.FailureReason,
      })),
    }));

    return res.json({ success: true, sourceFile, affectedUsers, totalErrors, users: preview });

  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n🚀 Migration Email Backend running on port ${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health`);
  console.log(`   Process: POST http://localhost:${PORT}/api/process-migration`);
  console.log(`   Preview: POST http://localhost:${PORT}/api/preview-migration\n`);
});
